const express   = require('express')
const app       = express()
const port      = 3000
const passport  = require("passport")
const cookieParser = require ("cookie-parser")
const session = require ("express-session")



// import
const c_beranda = require('./controller/c_beranda')
const c_auth    = require('./controller/c_auth')
const c_dashboard = require('./controller/c_dashboard')
const c_user    = require('./controller/c_user')
const c_master_produk    = require('./controller/c_master_produk')
const cek_login = c_auth.cek_login


// settingan session untuk login
app.use(cookieParser("secret"))
app.use( session({
    secret: "secret",
    resave: true,
    saveUninitialized: false,
    cookie: {
        maxAge: 1000 * 60 * 60 *2
        // batas session expire : 1000 mili detik * 60 = 1 menit
        // e menit * 60 = 1 jam
    }

}))
app.use(passport.initialize())
app.use(passport.session())



// settingan general
app.use(express.urlencoded({extended:false}))
app.set('view engine', 'ejs')
app.set('views', './view-html')
app.use(express.static('public'))


// route
app.get('/', c_beranda.index) 
app.get('/login', c_auth.form_login)
app.post("/proses-login", c_auth.proses_login)
app.get('/logout', c_auth.logout)

app.get("/dashboard", c_auth.cek_login, c_dashboard.index)

app.get("/master-produk", c_auth.cek_login, c_master_produk.index)
app.get("/master-produk/tambah", c_auth.cek_login, c_master_produk.form_tambah)
app.post("/master-produk/proses-simpan",c_auth.cek_login,c_master_produk.proses_simpan)
app.get("/master-produk/proses-hapus/:id",c_auth.cek_login,c_master_produk.proses_hapus)
app.get("/master-produk/edit/:id", c_auth.cek_login, c_master_produk.form_edit)
app.post("/master-produk/proses-edit/", c_auth.cek_login, c_master_produk.proses_edit)


app.get("/user-management",c_auth.cek_login,c_user.index)
app.get("/user/tambah",c_auth.cek_login,c_user.form_tambah)
app.post("/user/proses-simpan",c_auth.cek_login,c_user.proses_simpan)


app.listen(port, ()=>{
    console.log(`Aplikasi sudah siap, silahkan buka http://localhost:${port}`)
})